// Get the stored value from local storage
var storedValue1 = localStorage.getItem("adminPanelValue1");
var storedValue1_1 = localStorage.getItem("adminPanelValue1_1");

// Display the value in the specified element
var displayElement1 = document.getElementById("displayValue1");
displayElement1.textContent =  storedValue1;
var displayElement1_1 = document.getElementById("displayValue1_1");
displayElement1_1.textContent =  storedValue1_1;


// Get the stored value from local storage
var storedValue2 = localStorage.getItem("adminPanelValue2");
var storedValue2_1 = localStorage.getItem("adminPanelValue2_1");

// Display the value in the specified element
var displayElement2 = document.getElementById("displayValue2");
displayElement2.textContent =  storedValue2;
var displayElement2_1 = document.getElementById("displayValue2_1");
displayElement2_1.textContent =  storedValue2_1;

///

// Get the stored value from local storage
var storedValue3 = localStorage.getItem("adminPanelValue3");
var storedValue3_1 = localStorage.getItem("adminPanelValue3_1");

// Display the value in the specified element
var displayElement3 = document.getElementById("displayValue3");
displayElement3.textContent =  storedValue3;
var displayElement3_1 = document.getElementById("displayValue3_1");
displayElement3_1.textContent =  storedValue3_1;